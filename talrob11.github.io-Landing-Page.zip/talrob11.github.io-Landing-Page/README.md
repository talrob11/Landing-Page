# talrob11.github.io

Talya Roberts talyarob05@gmail.com

My Github account is supposed to record changes to my files allowing me to track my work.

The repository I created was just made to save any new work I do and to help teach me the basics of Github.

After logging into Github Desktop a pop up to clone a repository from the internet opened so I selected the repository I just created in my online browser and cloned it then made sure the clone is in a good location that I can remember. 